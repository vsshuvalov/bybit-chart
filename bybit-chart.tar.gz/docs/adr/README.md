# Architecture Decision Records — правила

**Дата:** 2026-08-10  
**Stage:** 0

---

## Назначение

ADR (Architecture Decision Record) фиксирует значимые архитектурные решения: контекст, рассмотренные варианты, принятое решение и последствия.

## Когда создавать ADR

ADR создаётся для каждого решения, которое:

- затрагивает более одного процесса или компонента;
- является необратимым или дорогостоящим в изменении;
- вызывает конфликт между нормативными документами;
- требует утверждения тимлида согласно §1.2 Roadmap.

## Обязательные ADR до начала реализации (§1.2 ROADMAP)

| ID | Решение | Статус |
|---|---|---|
| ADR-001 | Границы процессов и запрещённые зависимости | OPEN |
| ADR-002 | Protobuf-схемы, IPC и правила совместимости | OPEN |
| ADR-003 | Владение WAL, Parquet, manifest и checkpoint | OPEN |
| ADR-004 | Каноническая integer/Decimal-модель и wire-format | OPEN |
| ADR-005 | PostgreSQL для транзакционных данных | OPEN |
| ADR-006 | DataQuality, gaps, watermark и signal gating | OPEN |
| ADR-007 | Внутренний OrderIntent и единый Risk Engine | OPEN |
| ADR-008 | Граница поддерживаемого Pine-compatible subset | OPEN |
| ADR-009 | Симулятор исполнения и fill-модель | OPEN |
| ADR-010 | Жизненный цикл ML-модели и governance | OPEN |
| ADR-011 | Release, rollback, backup, RPO/RTO и secrets | OPEN |

Открытые вопросы подробно описаны в `docs/architecture/DECISIONS_PENDING.md`.

## Принятые ADR

| ID | Решение | Статус | Файл |
|---|---|---|---|
| ADR-004 | Decimal128 Precision/Scale для Arrow/Parquet Schema | ACCEPTED | `ADR-004-decimal128-precision-scale.md` |
| ADR-012 | Разделение development- и production-хоста (закрывает CONFLICT-004) | ACCEPTED | `ADR-012-development-and-production-hosts.md` |

ADR-004 частично закрывает обязательный ADR-004 из §1.2 (каноническая integer/Decimal-модель), фиксируя Decimal128 для Parquet. Wire-format и Protobuf-схемы остаются в OPEN до ADR-002.

ADR-012 принят вне обязательного списка §1.2: решение потребовалось раньше, чем ADR-001…011, потому что платформенная привязка dependency lock блокировала P1-S1-003. Остаточные открытые вопросы решения — в OPEN-005.

## Шаблон ADR

```markdown
# ADR-NNN: Название решения

**Дата:** YYYY-MM-DD  
**Статус:** PROPOSED | ACCEPTED | SUPERSEDED | DEPRECATED  
**Авторы:** …  
**Reviewer:** тимлид  

## Контекст

Почему это решение необходимо.

## Варианты

1. Вариант A — …
2. Вариант B — …

## Решение

Принятый вариант и обоснование.

## Последствия

- Положительные: …
- Отрицательные/компромиссы: …
- Риски: …

## Ссылки

- Roadmap §X
```

## Правила

- ADR не удаляется после принятия. При пересмотре создаётся новый ADR с `SUPERSEDED` у старого.
- Автор изменения не может единолично утверждать ADR, затрагивающий live risk, execution или модель (§1.3 Roadmap).
- `DECIDED` в `DECISIONS_PENDING.md` означает, что решение уже зафиксировано нормативными документами — отдельный ADR не нужен, но ссылка обязательна.
